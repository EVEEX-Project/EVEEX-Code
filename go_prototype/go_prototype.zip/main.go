package main

import "eveex/cmd"

func main() {
	cmd.Execute()
}
