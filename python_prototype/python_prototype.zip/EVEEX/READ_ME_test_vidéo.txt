
Sur un terminal (resp. une console), d'abord lancer "main_recepteur_video.py". Puis,
sur un autre terminal (resp. une autre console), lancer "main_emetteur_video.py".
L'envoi se fait par défaut sur le réseau local, mais cela peut être modifié très
simplement en changeant les adresses IP (+ éventuellement les ports) dans ces 2 scripts.
