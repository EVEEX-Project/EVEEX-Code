

Pour d'abord tester si la communication entre l'émetteur (Raspberry Pi avec une PiCamera) et le récepteur (PC
ou RPi) fonctionne, d'abord lancer "test_recepteur.py" sur le récepteur puis "test_emetteur.py" sur l'émetteur
(en changeant les adresses IP sur ces 2 scripts).

Puis, lancer "main_PC_recepteur.py" sur le récepteur (PC ou RPi) et "main_RPi_emettrice.py" sur la RPi 
pour la démo. Ne pas oublier d'également changer les adresses IP sur ces 2 derniers scripts.

Une fois la démo lancée, sur l'écran link à la RPi, il suffit d'appuyer sur la touche "q" du clavier afin
d'arrêter le flux vidéo de la PiCamera (et donc les 2 programmes en cours).

