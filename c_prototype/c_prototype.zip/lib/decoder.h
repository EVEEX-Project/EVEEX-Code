//
// Created by alexandre on 12/01/2021.
//

#ifndef C_PROTOTYPE_DECODER_H
#define C_PROTOTYPE_DECODER_H

void IDCT(const double *coeffs, void *macrobloc, int channel);

#endif //C_PROTOTYPE_DECODER_H
