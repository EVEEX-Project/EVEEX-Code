#ifndef BITSTREAM_H
#define BITSTREAM_H

#include "Object.h"

extern const void * const Bitstream(void);
extern const void * const BitstreamClass(void);

#endif //C_PROTOTYPE_BITSTREAM_H
