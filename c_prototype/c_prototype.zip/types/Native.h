#ifndef NATIVE_H
#define NATIVE_H

#include "Object.h"

extern const void * const Native(void);
extern const void * const NativeClass(void);

#endif
