#ifndef DICTIONARYITEM_H
#define DICTIONARYITEM_H

extern const void * const DictionaryItem(void);

#endif