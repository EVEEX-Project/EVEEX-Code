#ifndef PIXEL_H
#define PIXEL_H

#include "Object.h"

extern const void * const RGBPixel(void);

extern const void * const YUVPixel(void);

extern const void * const PixelClass(void);

#endif
