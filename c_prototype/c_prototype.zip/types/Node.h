#ifndef NODE_H
#define NODE_H

#include "Object.h"

extern const void * const Node(void);
extern const void * const NodeClass(void);

struct Node *copyNode(const void *self);

#endif
